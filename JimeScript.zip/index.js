const { Telegraf, Markup } = require('telegraf');
const { Low } = require('lowdb');
const { JSONFile } = require('lowdb/node');
const path = require('path');
const fs = require('fs');
const config = require('./config.json');

const { TOKEN, OWNER_ID, OWNER_USERNAME } = config;
const bot = new Telegraf(TOKEN);

// Setup database lowdb
const file = path.join(__dirname, 'db.json');
const adapter = new JSONFile(file);
const defaultData = {
    users: {},
    stok: {
        indonesia: { nominus: [], spam: [] },
        luar: { nominus: [], spam: [] }
    },
    harga: {
        indonesia_nominus: 5000,
        indonesia_spam: 3000,
        luar_nominus: 7000,
        luar_spam: 4000
    },
    dana: "089xxxxxxxx",
    gopay: "089xxxxxxxx",
    maintenance: false,
    channel_notif: "",
    total_deposit: 0,
    total_stok_terjual: 0,
    pending_deposit: {}, // buat nyimpen data deposit yang nunggu ACC
    state: {}
};
const db = new Low(adapter, defaultData);

// Helper
const isOwner = (userId) => userId === OWNER_ID;
const fmt = (num) => num.toLocaleString('id-ID');

async function initDB() {
    await db.read();
    db.data ||= defaultData;
    await db.write();
}

async function kirimMenuUtama(ctx, edit = false) {
    const user = ctx.from;
    db.data.users[user.id] = {
        username: user.username || 'no_username',
        saldo: db.data.users[user.id]?.saldo || 0
    };
    await db.write();

    if (db.data.maintenance &&!isOwner(user.id)) {
        const text = "⚠️ Bot sedang maintenance.\nSilakan kembali beberapa saat lagi.";
        return edit? ctx.editMessageText(text) : ctx.reply(text);
    }

    const keyboard = [
        [Markup.button.callback('🛒 Stok', 'menu_stok'), Markup.button.callback('💰 Price List', 'price_list')],
        [Markup.button.callback('🇮🇩 Indonesia', 'menu_indo'), Markup.button.callback('🌍 Negara Lain', 'menu_luar')],
        [Markup.button.callback('💳 Deposit Saldo', 'deposit'), Markup.button.callback('📞 Owner', 'owner')],
        [Markup.button.callback('🔄 Refresh Stok', 'refresh'), Markup.button.callback('ℹ️ Bantuan', 'bantuan')]
    ];
    if (isOwner(user.id)) {
        keyboard.push([Markup.button.callback('👑 PANEL OWNER', 'panel_owner')]);
    }

    const text = `
👋 Halo, ${user.first_name}!

🏪 Selamat Datang di TGSHOP
Cepat • Aman • Terpercaya

━━━━━━━━━━━━━━━━━━━

⚡ Instant Delivery
🔒 Secure Checkout
💬 Friendly Support
🌍 Berbagai Negara
🔥 Stok Update Setiap Hari

━━━━━━━━━━━━━━━━━━━

Pilih menu di bawah untuk melanjutkan 👇
`;
    if (edit) {
        try {
            await ctx.editMessageText(text, Markup.inlineKeyboard(keyboard));
        } catch (e) {
            await ctx.reply(text, Markup.inlineKeyboard(keyboard));
        }
    } else {
        await ctx.reply(text, Markup.inlineKeyboard(keyboard));
    }
}

// Session sederhana pake db
bot.use(async (ctx, next) => {
    ctx.session = db.data.state[ctx.from?.id] || {};
    await next();
    db.data.state[ctx.from?.id] = ctx.session;
    await db.write();
});

// ====== COMMAND ======
bot.start(async (ctx) => {
    ctx.session = {};
    await kirimMenuUtama(ctx);
});

bot.command('batal', async (ctx) => {
    ctx.session = {};
    await ctx.reply('Dibatalkan.');
    await kirimMenuUtama(ctx);
});

// ====== CALLBACK HANDLER ======
bot.on('callback_query', async (ctx) => {
    await ctx.answerCbQuery();
    const data = ctx.callbackQuery.data;
    const user = ctx.from;

    if (db.data.maintenance &&!isOwner(user.id) &&!['bantuan', 'owner', 'back_start'].includes(data)) {
        return ctx.editMessageText("⚠️ Bot sedang maintenance.\nSilakan kembali beberapa saat lagi.");
    }

    // ====== MENU USER ======
    if (data === 'menu_stok') {
        const keyboard = [
            [Markup.button.callback('🔹 Stok Nominus', 'stok_nominus_all')],
            [Markup.button.callback('🔸 Stok Spam', 'stok_spam_all')],
            [Markup.button.callback('⬅️ Kembali', 'back_start')]
        ];
        await ctx.editMessageText("📦 PILIH JENIS STOK\n\nPilih jenis stok:", Markup.inlineKeyboard(keyboard));
    }

    else if (data === 'menu_indo') {
        const keyboard = [
            [Markup.button.callback('🔹 Stok Nominus', 'stok_nominus_indonesia')],
            [Markup.button.callback('🔸 Stok Spam', 'stok_spam_indonesia')],
            [Markup.button.callback('⬅️ Kembali', 'back_start')]
        ];
        await ctx.editMessageText("🇮🇩 STOK INDONESIA\n\nPilih jenis stok:", Markup.inlineKeyboard(keyboard));
    }

    else if (data === 'menu_luar') {
        const keyboard = [
            [Markup.button.callback('🔹 Stok Nominus', 'stok_nominus_luar')],
            [Markup.button.callback('🔸 Stok Spam', 'stok_spam_luar')],
            [Markup.button.callback('⬅️ Kembali', 'back_start')]
        ];
        await ctx.editMessageText("🌍 STOK NEGARA LAIN\n\nPilih jenis stok:", Markup.inlineKeyboard(keyboard));
    }

    else if (data.startsWith('stok_')) {
        const [, jenis, negara] = data.split('_');
        let stokList = [];
        if (negara === 'indonesia') stokList = db.data.stok.indonesia[jenis];
        else if (negara === 'luar') stokList = db.data.stok.luar[jenis];
        else stokList = [...db.data.stok.indonesia[jenis],...db.data.stok.luar[jenis]];

        let text = stokList.length === 0
        ? "❌ Maaf Stok Sudah Habis\n\n📞 Hubungi Owner untuk informasi restock."
            : `✅ Stok ${jenis.toUpperCase()} tersedia: ${stokList.length} item\n\nSilakan order via owner ${OWNER_USERNAME}`;

        const keyboard = [[Markup.button.callback('⬅️ Kembali', 'back_start')]];
        await ctx.editMessageText(text, Markup.inlineKeyboard(keyboard));
    }

    else if (data === 'price_list') {
        const h = db.data.harga;
        const text = `
💰 PRICE LIST

🇮🇩 Indonesia
🔹 Nominus: Rp ${fmt(h.indonesia_nominus)}
🔸 Spam: Rp ${fmt(h.indonesia_spam)}

🌍 Negara Lain
🔹 Nominus: Rp ${fmt(h.luar_nominus)}
🔸 Spam: Rp ${fmt(h.luar_spam)}
`;
        const keyboard = [[Markup.button.callback('⬅️ Kembali', 'back_start')]];
        await ctx.editMessageText(text, Markup.inlineKeyboard(keyboard));
    }

    else if (data === 'deposit') {
        const keyboard = [
            [Markup.button.callback('💙 Dana', 'deposit_dana')],
            [Markup.button.callback('🟢 GoPay', 'deposit_gopay')],
            [Markup.button.callback('⬅️ Kembali', 'back_start')]
        ];
        await ctx.editMessageText("💳 DEPOSIT SALDO\n\nPilih metode pembayaran:", Markup.inlineKeyboard(keyboard));
    }

    else if (data === 'deposit_dana') {
        const text = `
💙 DEPOSIT VIA DANA

Nomor Tujuan:
${db.data.dana}

Setelah transfer silakan kirim screenshot bukti pembayaran.
`;
        ctx.session.deposit_method = 'DANA';
        const keyboard = [[Markup.button.callback('⬅️ Kembali', 'deposit')]];
        await ctx.editMessageText(text, Markup.inlineKeyboard(keyboard));
    }

    else if (data === 'deposit_gopay') {
        const text = `
🟢 DEPOSIT VIA GOPAY

Nomor Tujuan:
${db.data.gopay}

Setelah transfer silakan kirim screenshot bukti pembayaran.
`;
        ctx.session.deposit_method = 'GOPAY';
        const keyboard = [[Markup.button.callback('⬅️ Kembali', 'deposit')]];
        await ctx.editMessageText(text, Markup.inlineKeyboard(keyboard));
    }

    else if (['owner', 'bantuan'].includes(data)) {
        const text = `
📞 OWNER

Username: ${OWNER_USERNAME}

Jika mengalami kendala saat pembelian atau deposit, silakan hubungi owner.
`;
        const keyboard = [[Markup.button.callback('⬅️ Kembali', 'back_start')]];
        await ctx.editMessageText(text, Markup.inlineKeyboard(keyboard));
    }

    else if (data === 'refresh' || data === 'back_start') {
        ctx.session = {};
        await kirimMenuUtama(ctx, true);
    }

    // ====== ACC/TOLAK DEPOSIT VIA TOMBOL ======
    else if (data.startsWith('acc_dep_') && isOwner(user.id)) {
        const depositId = data.replace('acc_dep_', '');
        const dep = db.data.pending_deposit[depositId];
        if (!dep) return ctx.answerCbQuery('Data deposit tidak ditemukan', { show_alert: true });

        ctx.session.action = 'acc_nominal';
        ctx.session.acc_deposit_id = depositId;
        await ctx.reply(`Masukkan nominal untuk ACC deposit dari @${dep.username}:\n\nID: ${dep.userId}\nMetode: ${dep.method}`);
    }

    else if (data.startsWith('tolak_dep_') && isOwner(user.id)) {
        const depositId = data.replace('tolak_dep_', '');
        const dep = db.data.pending_deposit[depositId];
        if (!dep) return ctx.answerCbQuery('Data deposit tidak ditemukan', { show_alert: true });

        delete db.data.pending_deposit[depositId];
        await db.write();

        await ctx.editMessageReplyMarkup(); // hapus tombol
        await ctx.reply(`❌ Deposit dari @${dep.username} ditolak`);
        try {
            await bot.telegram.sendMessage(dep.userId, `❌ Deposit kamu ditolak owner. Hubungi ${OWNER_USERNAME} untuk info lebih lanjut.`);
        } catch (e) {}
    }

    // ====== PANEL OWNER ======
    else if (data === 'panel_owner' && isOwner(user.id)) {
        const keyboard = [
            [Markup.button.callback('➕ Add Stok', 'owner_add_stok'), Markup.button.callback('➖ Delete Stok', 'owner_del_stok')],
            [Markup.button.callback('💰 Atur Harga', 'owner_harga'), Markup.button.callback('💵 Add Saldo Buyer', 'owner_add_saldo')],
            [Markup.button.callback('💙 Atur Dana', 'owner_set_dana'), Markup.button.callback('🟢 Atur GoPay', 'owner_set_gopay')],
            [Markup.button.callback('📢 Broadcast', 'owner_broadcast'), Markup.button.callback('📣 Channel Notifikasi', 'owner_channel')],
            [Markup.button.callback('📦 List Stok', 'owner_list_stok'), Markup.button.callback('📊 Statistik', 'owner_stat')],
            [Markup.button.callback('🟢 Maintenance ON', 'owner_maint_on'), Markup.button.callback('🔴 Maintenance OFF', 'owner_maint_off')],
            [Markup.button.callback('🔄 Backup Database', 'owner_backup')],
            [Markup.button.callback('⬅️ Kembali', 'back_start')]
        ];
        await ctx.editMessageText("👑 PANEL OWNER\n\nPilih aksi:", Markup.inlineKeyboard(keyboard));
    }

    // ADD STOK
    else if (data === 'owner_add_stok' && isOwner(user.id)) {
        ctx.session.action = 'add_stok_step1';
        const keyboard = [
            [Markup.button.callback('🇮🇩 Indonesia', 'add_stok_indo'), Markup.button.callback('🌍 Negara Lain', 'add_stok_luar')],
            [Markup.button.callback('⬅️ Batal', 'panel_owner')]
        ];
        await ctx.editMessageText("➕ ADD STOK\n\nPilih negara:", Markup.inlineKeyboard(keyboard));
    }
    else if (data.startsWith('add_stok_') && isOwner(user.id)) {
        ctx.session.add_negara = data.split('_')[2];
        ctx.session.action = 'add_stok_step2';
        const keyboard = [
            [Markup.button.callback('🔹 Nominus', 'add_stok_jenis_nominus'), Markup.button.callback('🔸 Spam', 'add_stok_jenis_spam')],
            [Markup.button.callback('⬅️ Batal', 'panel_owner')]
        ];
        await ctx.editMessageText("➕ ADD STOK\n\nPilih jenis stok:", Markup.inlineKeyboard(keyboard));
    }
    else if (data.startsWith('add_stok_jenis_') && isOwner(user.id)) {
        ctx.session.add_jenis = data.split('_')[3];
        ctx.session.action = 'add_stok_step3';
        await ctx.editMessageText(`➕ ADD STOK\n\nKirim data stok ${ctx.session.add_negara} ${ctx.session.add_jenis}.\n\nFormat: 1 baris = 1 stok\nContoh:\nemail1|pass1\nemail2|pass2\n\nKetik /batal untuk cancel`,
            Markup.inlineKeyboard([[Markup.button.callback('⬅️ Batal', 'panel_owner')]]));
    }

    // DELETE STOK
    else if (data === 'owner_del_stok' && isOwner(user.id)) {
        ctx.session.action = 'del_stok_step1';
        const keyboard = [
            [Markup.button.callback('🇮🇩 Indonesia', 'del_stok_indo'), Markup.button.callback('🌍 Negara Lain', 'del_stok_luar')],
            [Markup.button.callback('⬅️ Batal', 'panel_owner')]
        ];
        await ctx.editMessageText("➖ DELETE STOK\n\nPilih negara:", Markup.inlineKeyboard(keyboard));
    }
    else if (data.startsWith('del_stok_') && isOwner(user.id) &&!data.includes('jenis')) {
        ctx.session.del_negara = data.split('_')[2];
        ctx.session.action = 'del_stok_step2';
        const keyboard = [
            [Markup.button.callback('🔹 Nominus', 'del_stok_jenis_nominus'), Markup.button.callback('🔸 Spam', 'del_stok_jenis_spam')],
            [Markup.button.callback('⬅️ Batal', 'panel_owner')]
        ];
        await ctx.editMessageText("➖ DELETE STOK\n\nPilih jenis stok:", Markup.inlineKeyboard(keyboard));
    }
    else if (data.startsWith('del_stok_jenis_') && isOwner(user.id)) {
        const jenis = data.split('_')[3];
        const negara = ctx.session.del_negara;
        const stokList = db.data.stok[negara][jenis];

        if (stokList.length === 0) {
            await ctx.editMessageText("❌ Stok kosong, gak ada yang bisa dihapus.", Markup.inlineKeyboard([[Markup.button.callback('⬅️ Kembali', 'panel_owner')]]));
            ctx.session = {};
            return;
        }

        let text = `➖ DELETE STOK ${negara.toUpperCase()} ${jenis.toUpperCase()}\n\nPilih nomor stok yang mau dihapus:\n\n`;
        stokList.slice(0, 20).forEach((item, i) => {
            text += `${i+1}. ${item.substring(0, 25)}...\n`;
        });
        if (stokList.length > 20) text += `\n...dan ${stokList.length - 20} lainnya`;

        ctx.session.action = 'del_stok_step3';
        ctx.session.del_jenis = jenis;
        await ctx.editMessageText(text + '\n\nKirim nomor stok yang mau dihapus. Ketik /batal untuk cancel',
            Markup.inlineKeyboard([[Markup.button.callback('⬅️ Batal', 'panel_owner')]]));
    }

    // ATUR HARGA
    else if (data === 'owner_harga' && isOwner(user.id)) {
        ctx.session.action = 'atur_harga_step1';
        const keyboard = [
            [Markup.button.callback('🇮🇩 Indo Nominus', 'harga_indonesia_nominus'), Markup.button.callback('🇮🇩 Indo Spam', 'harga_indonesia_spam')],
            [Markup.button.callback('🌍 Luar Nominus', 'harga_luar_nominus'), Markup.button.callback('🌍 Luar Spam', 'harga_luar_spam')],
            [Markup.button.callback('⬅️ Batal', 'panel_owner')]
        ];
        await ctx.editMessageText("💰 ATUR HARGA\n\nPilih kategori:", Markup.inlineKeyboard(keyboard));
    }
    else if (data.startsWith('harga_') && isOwner(user.id)) {
        ctx.session.harga_key = data.replace('harga_', '');
        ctx.session.action = 'atur_harga_step2';
        await ctx.editMessageText(`💰 ATUR HARGA\n\nHarga sekarang: Rp ${fmt(db.data.harga[ctx.session.harga_key])}\n\nKirim harga baru dalam angka saja:`, Markup.inlineKeyboard([[Markup.button.callback('⬅️ Batal', 'panel_owner')]]));
    }

    // ADD SALDO BUYER
    else if (data === 'owner_add_saldo' && isOwner(user.id)) {
        ctx.session.action = 'add_saldo_step1';
        await ctx.editMessageText("💵 ADD SALDO BUYER\n\nKirim ID Telegram buyer:", Markup.inlineKeyboard([[Markup.button.callback('⬅️ Batal', 'panel_owner')]]));
    }

    // ATUR DANA/GOPAY
    else if (data === 'owner_set_dana' && isOwner(user.id)) {
        ctx.session.action = 'set_dana';
        await ctx.editMessageText('💙 Kirim nomor DANA baru:', Markup.inlineKeyboard([[Markup.button.callback('⬅️ Batal', 'panel_owner')]]));
    }
    else if (data === 'owner_set_gopay' && isOwner(user.id)) {
        ctx.session.action = 'set_gopay';
        await ctx.editMessageText('🟢 Kirim nomor GoPay baru:', Markup.inlineKeyboard([[Markup.button.callback('⬅️ Batal', 'panel_owner')]]));
    }

    // BROADCAST
    else if (data === 'owner_broadcast' && isOwner(user.id)) {
        ctx.session.action = 'broadcast';
        await ctx.editMessageText('📢 BROADCAST\n\nKirim pesan yang mau di-broadcast ke semua user:', Markup.inlineKeyboard([[Markup.button.callback('⬅️ Batal', 'panel_owner')]]));
    }

    // CHANNEL NOTIFIKASI
    else if (data === 'owner_channel' && isOwner(user.id)) {
        ctx.session.action = 'set_channel';
        await ctx.editMessageText(`📣 CHANNEL NOTIFIKASI\n\nChannel sekarang: ${db.data.channel_notif || 'Belum diset'}\n\nKirim username channel baru, contoh: @channelkamu`, Markup.inlineKeyboard([[Markup.button.callback('⬅️ Batal', 'panel_owner')]]));
    }

    // LIST STOK
    else if (data === 'owner_list_stok' && isOwner(user.id)) {
        const s = db.data.stok;
        const text = `
📦 LIST STOK

🇮🇩 Indonesia
🔹 Nominus: ${s.indonesia.nominus.length} item
🔸 Spam: ${s.indonesia.spam.length} item

🌍 Negara Lain
🔹 Nominus: ${s.luar.nominus.length} item
🔸 Spam: ${s.luar.spam.length} item
`;
        const keyboard = [[Markup.button.callback('⬅️ Kembali', 'panel_owner')]];
        await ctx.editMessageText(text, Markup.inlineKeyboard(keyboard));
    }

    // STATISTIK
    else if (data === 'owner_stat' && isOwner(user.id)) {
        const totalUser = Object.keys(db.data.users).length;
        const totalStok = Object.values(db.data.stok).reduce((sum, negara) =>
            sum + Object.values(negara).reduce((s, arr) => s + arr.length, 0), 0);

        const text = `
📊 STATISTIK

- Total User: ${totalUser}
- Total Deposit: Rp ${fmt(db.data.total_deposit)}
- Total Saldo Masuk: Rp ${fmt(db.data.total_deposit)}
- Total Stok: ${totalStok}
- Total Stok Terjual: ${db.data.total_stok_terjual}
`;
        const keyboard = [[Markup.button.callback('⬅️ Kembali', 'panel_owner')]];
        await ctx.editMessageText(text, Markup.inlineKeyboard(keyboard));
    }

    // MAINTENANCE
    else if (data === 'owner_maint_on' && isOwner(user.id)) {
        db.data.maintenance = true;
        await db.write();
        await ctx.answerCbQuery("Maintenance ON");
        ctx.callbackQuery.data = 'panel_owner';
        await bot.handleUpdate(ctx.update);
    }
    else if (data === 'owner_maint_off' && isOwner(user.id)) {
        db.data.maintenance = false;
        await db.write();
        await ctx.answerCbQuery("Maintenance OFF");
        ctx.callbackQuery.data = 'panel_owner';
        await bot.handleUpdate(ctx.update);
    }

    // BACKUP DATABASE
    else if (data === 'owner_backup' && isOwner(user.id)) {
        const backupName = `backup-${Date.now()}.json`;
        fs.copyFileSync(file, backupName);
        await ctx.replyWithDocument({ source: backupName, filename: backupName });
        await ctx.answerCbQuery("Backup berhasil");
        fs.unlinkSync(backupName);
    }

    else {
        await ctx.editMessageText(
            "Fitur belum diimplementasi.\nSilakan hubungi " + OWNER_USERNAME,
            Markup.inlineKeyboard([[Markup.button.callback('⬅️ Kembali', 'back_start')]])
        );
    }
});

// Handle text buat input owner
bot.on('text', async (ctx) => {
    if (!isOwner(ctx.from.id)) return;

    if (ctx.session.action === 'set_dana') {
        db.data.dana = ctx.message.text;
        await db.write();
        ctx.session = {};
        await ctx.reply('✅ Nomor DANA berhasil diupdate');
        await kirimMenuUtama(ctx);
    }
    else if (ctx.session.action === 'set_gopay') {
        db.data.gopay = ctx.message.text;
        await db.write();
        ctx.session = {};
        await ctx.reply('✅ Nomor GoPay berhasil diupdate');
        await kirimMenuUtama(ctx);
    }
    else if (ctx.session.action === 'add_stok_step3') {
        const stokBaru = ctx.message.text.split('\n').filter(x => x.trim()!== '');
        const { add_negara, add_jenis } = ctx.session;
        db.data.stok[add_negara][add_jenis].push(...stokBaru);
        await db.write();

        if (db.data.channel_notif) {
            try {
                await bot.telegram.sendMessage(db.data.channel_notif, `🔥 RESTOCK!\n\n${add_negara.toUpperCase()} ${add_jenis.toUpperCase()}: +${stokBaru.length} item\n\nCek bot sekarang!`);
            } catch (e) {}
        }

        ctx.session = {};
        await ctx.reply(`✅ Berhasil nambah ${stokBaru.length} stok ${add_negara} ${add_jenis}`);
        await kirimMenuUtama(ctx);
    }
    else if (ctx.session.action === 'del_stok_step3') {
        const idx = parseInt(ctx.message.text) - 1;
        const { del_negara, del_jenis } = ctx.session;
        const stokList = db.data.stok[del_negara][del_jenis];

        if (isNaN(idx) || idx < 0 || idx >= stokList.length) {
            return ctx.reply('❌ Nomor tidak valid');
        }

        const deleted = stokList.splice(idx, 1);
        await db.write();
        ctx.session = {};
        await ctx.reply(`✅ Berhasil hapus stok: ${deleted[0].substring(0, 30)}...`);
        await kirimMenuUtama(ctx);
    }
    else if (ctx.session.action === 'atur_harga_step2') {
        const hargaBaru = parseInt(ctx.message.text);
        if (isNaN(hargaBaru)) return ctx.reply('❌ Harus angka');
        db.data.harga[ctx.session.harga_key] = hargaBaru;
        await db.write();
        ctx.session = {};
        await ctx.reply(`✅ Harga berhasil diupdate jadi Rp ${fmt(hargaBaru)}`);
        await kirimMenuUtama(ctx);
    }
    else if (ctx.session.action === 'add_saldo_step1') {
        const userId = ctx.message.text;
        if (!db.data.users[userId]) return ctx.reply('❌ User tidak ditemukan. User harus /start dulu');
        ctx.session.add_saldo_user = userId;
        ctx.session.action = 'add_saldo_step2';
        await ctx.reply(`User: ${db.data.users[userId].username}\nSaldo sekarang: Rp ${fmt(db.data.users[userId].saldo)}\n\nKirim nominal yang mau ditambah:`);
    }
    else if (ctx.session.action === 'add_saldo_step2') {
        const nominal = parseInt(ctx.message.text);
        if (isNaN(nominal)) return ctx.reply('❌ Harus angka');
        const userId = ctx.session.add_saldo_user;
        db.data.users[userId].saldo += nominal;
        await db.write();
        ctx.session = {};
        await ctx.reply(`✅ Saldo user ${userId} ditambah Rp ${fmt(nominal)}`);
        try {
            await bot.telegram.sendMessage(userId, `💵 Saldo kamu ditambah Rp ${fmt(nominal)} oleh owner. Saldo sekarang: Rp ${fmt(db.data.users[userId].saldo)}`);
        } catch (e) {}
        await kirimMenuUtama(ctx);
    }
    else if (ctx.session.action === 'broadcast') {
        const pesan = ctx.message.text;
        let sukses = 0, gagal = 0;
        await ctx.reply('⏳ Mulai broadcast...');
        for (const userId of Object.keys(db.data.users)) {
            try {
                await bot.telegram.sendMessage(userId, `📢 BROADCAST\n\n${pesan}`);
                sukses++;
            } catch (e) {
                gagal++;
            }
        }
        ctx.session = {};
        await ctx.reply(`✅ Broadcast selesai\nBerhasil: ${sukses}\nGagal: ${gagal}`);
        await kirimMenuUtama(ctx);
    }
    else if (ctx.session.action === 'set_channel') {
        db.data.channel_notif = ctx.message.text;
        await db.write();
        ctx.session = {};
        await ctx.reply(`✅ Channel notifikasi diset ke ${ctx.message.text}`);
        await kirimMenuUtama(ctx);
    }
    else if (ctx.session.action === 'acc_nominal') {
        const nominal = parseInt(ctx.message.text);
        if (isNaN(nominal)) return ctx.reply('❌ Harus angka');
        const depositId = ctx.session.acc_deposit_id;
        const dep = db.data.pending_deposit[depositId];
        if (!dep) return ctx.reply('❌ Data deposit sudah tidak ada');

        db.data.users[dep.userId].saldo += nominal;
        db.data.total_deposit += nominal;
        delete db.data.pending_deposit[depositId];
        await db.write();

        ctx.session = {};
        await ctx.reply(`✅ Deposit @${dep.username} sebesar Rp ${fmt(nominal)} berhasil di-ACC`);
        try {
            await bot.telegram.sendMessage(dep.userId, `✅ Deposit Rp ${fmt(nominal)} berhasil. Saldo kamu sekarang: Rp ${fmt(db.data.users[dep.userId].saldo)}`);
        } catch (e) {}
    }
});

// Handle foto bukti deposit - SEKARANG PAKE TOMBOL
bot.on('photo', async (ctx) => {
    if (ctx.session?.deposit_method) {
        const method = ctx.session.deposit_method;
        const user = ctx.from;
        const photoId = ctx.message.photo.pop().file_id;

        const depositId = `${user.id}_${Date.now()}`;
        db.data.pending_deposit[depositId] = {
            userId: user.id,
            username: user.username || 'no_username',
            method: method,
            timestamp: Date.now()
        };
        await db.write();

        const caption = `📥 BUKTI DEPOSIT MASUK\n\nDari: @${user.username || 'no_username'} | \`${user.id}\`\nMetode: ${method}`;
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('✅ ACC', `acc_dep_${depositId}`), Markup.button.callback('❌ Tolak', `tolak_dep_${depositId}`)]
        ]);

        await bot.telegram.sendPhoto(OWNER_ID, photoId, { caption, parse_mode: 'Markdown',...keyboard });
        await ctx.reply("✅ Bukti pembayaran sudah dikirim ke owner. Tunggu verifikasi ya.");
        delete ctx.session.deposit_method;
    }
});

async function main() {
    await initDB();
    bot.launch();
    console.log('Bot jalan...');
}

main();

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));